/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_131()
{
    return 3287533896U;
}

void setval_347(unsigned *p)
{
    *p = 3287517512U;
}

unsigned addval_439(unsigned x)
{
    return x + 2430568520U;
}

unsigned addval_241(unsigned x)
{
    return x + 2448656712U;
}

unsigned addval_360(unsigned x)
{
    return x + 3750316043U;
}

void setval_362(unsigned *p)
{
    *p = 4085860492U;
}

unsigned getval_223()
{
    return 3284284232U;
}

unsigned addval_322(unsigned x)
{
    return x + 3330885686U;
}

unsigned addval_218(unsigned x)
{
    return x + 3284699464U;
}

unsigned getval_469()
{
    return 3284568394U;
}

unsigned addval_449(unsigned x)
{
    return x + 3284572488U;
}

unsigned getval_403()
{
    return 2428930376U;
}

unsigned addval_248(unsigned x)
{
    return x + 3284283736U;
}

unsigned addval_108(unsigned x)
{
    return x + 3284240712U;
}

unsigned addval_495(unsigned x)
{
    return x + 3258009733U;
}

unsigned getval_159()
{
    return 3286206792U;
}

void setval_161(unsigned *p)
{
    *p = 3284240712U;
}

unsigned addval_181(unsigned x)
{
    return x + 3351349576U;
}

void setval_390(unsigned *p)
{
    *p = 2497677640U;
}

unsigned addval_116(unsigned x)
{
    return x + 4213096793U;
}

unsigned addval_262(unsigned x)
{
    return x + 3281017088U;
}

unsigned getval_440()
{
    return 1304648157U;
}

unsigned getval_214()
{
    return 3351349576U;
}

unsigned getval_244()
{
    return 3284699976U;
}

void setval_404(unsigned *p)
{
    *p = 2417621633U;
}

unsigned getval_125()
{
    return 3284283720U;
}

unsigned getval_157()
{
    return 3267922248U;
}

void setval_312(unsigned *p)
{
    *p = 3284699464U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
