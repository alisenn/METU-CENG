#include <iostream>
#include "tracer.h"
#include "raytracer.h"
using namespace std;
using namespace parser;

void setValues(double& tmin,ObjectInfo& hitedMin,double& t, ObjectInfo hitinfo){
	t=hitinfo.t_value;
	if (hitinfo.hitted && hitinfo.t_value>=0 && t<tmin){
		if (t<tmin){
			tmin = t;
			hitedMin=hitinfo;
		}
	}
}

void setAllInMain(const Scene& scene, unsigned char* image, int min_height, int max_height,int width, int c){

	for (int i=min_height; i<max_height; i++)
	{
		for (int j=0; j<width; j++)
		{
			Ray r;
			double tmin = 40000;
			ObjectInfo hitedMin;
			hitedMin.hitted=false;
			r = rayMaker(i,j,scene.cameras[c]);

			ObjectInfo hitinfo;
			int ssize = scene.spheres.size();
			int msize = scene.meshes.size();
			int tsize = scene.triangles.size();
			double t;
			for (int k=0;k<ssize; k++)
			{
				hitinfo = collionCheckSphere(r,scene.spheres[k],scene);
				setValues(tmin,hitedMin,t,hitinfo);
			}

			for (int k=0;k<tsize;k++)
			{
			 hitinfo = triangleIntersection(r,scene.triangles[k],scene);
			 setValues(tmin,hitedMin,t,hitinfo);

		 }
		 for( int k = 0; k< msize; k++){
			 hitinfo = intersectionMesh(r,scene,scene.meshes[k]);
			 setValues(tmin,hitedMin,t,hitinfo);
		 }

			Vec3f pixelColor = tracer(r,hitedMin,scene,scene.cameras[c],scene.max_recursion_depth);
			int idx = i*width*3 + 3*j;

			if(pixelColor.x> 255)
				image[idx++] = 255;
			else
				image[idx++] = round(pixelColor.x);
			if(pixelColor.y> 255)
				image[idx++] = 255;
			else
				image[idx++] = round(pixelColor.y);
			if(pixelColor.z> 255)
				image[idx++] = 255;
			else
				image[idx++] = round(pixelColor.z);
		}
	}
}
