#ifndef SETALLINMAIN_H
#define SETALLINMAIN_H
#include "parser.h"
using namespace std;
using namespace parser;
void setValues(double& tmin,ObjectInfo& hitedMin,double& t, ObjectInfo hitinfo);
void setAllInMain(const Scene& scene, unsigned char* image, int min_height, int max_height,int width, int c);
#endif
