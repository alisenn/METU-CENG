#include <iostream>
#include "tracer.h"
#include "raytracer.h"
using namespace std;
using namespace parser;

bool isShadow(const ObjectInfo &hitInfoResult,const Scene &s,const Vec3f &lightVector)
{
  Ray ray;
  Vec3f epsilon,wi;
  wi = normalize(subtract(lightVector, hitInfoResult.intersection));

  ray.b = wi;

  epsilon = mult(wi,s.shadow_ray_epsilon);

  ray.a = add(hitInfoResult.intersection,epsilon);


  ObjectInfo hittedObj;

  double tOfLight = subtract(lightVector, ray.a).x / ray.b.x;
  int sphereLength = s.spheres.size();
  int triangleLength = s.triangles.size();
  int meshLength = s.meshes.size();

  for(int i = 0; i < sphereLength; i++)
  {
      Sphere sphere = s.spheres[i];
      hittedObj = collionCheckSphere(ray,sphere, s);

      if(hittedObj.hitted)
        if(tOfLight > hittedObj.t_value && hittedObj.t_value >= 0)
            return true;
  }


   for(int i = 0; i < triangleLength; i++)
   {
       Triangle tri = s.triangles[i];
       hittedObj = triangleIntersection(ray,tri, s);

       if(hittedObj.hitted)
         if(tOfLight > hittedObj.t_value && hittedObj.t_value >= 0)
             return true;
   }

    for(int i = 0; i < meshLength; i++)
    {
        Mesh mesh = s.meshes[i];
        hittedObj = intersectionMesh(ray,s,mesh);

        if(hittedObj.hitted)
          if(tOfLight > hittedObj.t_value && hittedObj.t_value >= 0)
              return true;
    }

    return false;
}
