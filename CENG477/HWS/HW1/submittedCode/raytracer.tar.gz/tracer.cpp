#include <iostream>
#include "tracer.h"
#include "raytracer.h"
using namespace std;
using namespace parser;


Vec3f tracer(const Ray &r, const ObjectInfo &ObjInfo,const Scene &s, const Camera &cam, int maxDepth)
{
    Vec3f pixelColor;

    if(!ObjInfo.hitted)
    {
      pixelColor.x = s.background_color.x;
      pixelColor.y = s.background_color.y;
      pixelColor.z = s.background_color.z;
      return pixelColor;
    }
    else
    {
      int numspheres,numtris,nummeshes;
      int materialIndex=ObjInfo.material_id -1;
      numspheres = s.spheres.size();
      numtris = s.triangles.size();
      nummeshes = s.meshes.size();

      pixelColor=pointWise(s.materials[materialIndex].ambient,s.ambient_light);

      int numLights = s.point_lights.size();

  		for(int l = 0; l < numLights; l++)
  		{

		    PointLight light = s.point_lights[l];
        Vec3f lightPos,diffuse, specular,irradiance;
        Vec3f lightVector,h;
        double distanceSquare,dotProd,e;
        lightPos=light.position;

        if(isShadow(ObjInfo,s,lightPos))
          continue;

        distanceSquare = distance(ObjInfo.intersection,lightPos);
        distanceSquare *= distanceSquare;

        irradiance.x = light.intensity.x/distanceSquare;
        irradiance.y = light.intensity.y/distanceSquare;
        irradiance.z = light.intensity.z/distanceSquare;

      	lightVector = normalize(subtract(lightPos, ObjInfo.intersection));

      	dotProd = dot(lightVector, ObjInfo.normal);
      	dotProd = (dotProd < 0 ) ?  0 : dotProd ;

        diffuse = pointWise( mult(s.materials[materialIndex].diffuse,dotProd),irradiance);
        pixelColor=add(pixelColor,diffuse);

        //calculating specular
      	h  = normalize(subtract(lightVector, r.b));

        dotProd = dot(h, ObjInfo.normal);
        dotProd = (dotProd < 0 ) ?  0 : dotProd ;

        e = s.materials[materialIndex].phong_exponent;
        specular = pointWise( mult(s.materials[materialIndex].specular,pow(dotProd,e)),irradiance);
        pixelColor=add(pixelColor,specular);

    	}
      //chech mirror attribute
      Vec3f met;
      met = s.materials[materialIndex].mirror;
      if(met.x == 0 && met.y == 0 && met.z == 0) return pixelColor;
      if(maxDepth<=0) return pixelColor;

      Vec3f yansitma,nWi,wiEps;
      double wi;
      Ray mirrorRay;

      yansitma.x = 0;
      yansitma.y = 0;
      yansitma.z = 0;

    	wi = -2 * dot(r.b, ObjInfo.normal);
      nWi = normalize(add(mult(ObjInfo.normal,wi),r.b));
      mirrorRay.b = nWi;

      wiEps = mult(nWi,s.shadow_ray_epsilon);

      mirrorRay.a = add(ObjInfo.intersection,wiEps);

      double tmin = 999999;
      double t;
      ObjectInfo hitedMin;
      hitedMin.hitted = false;

      for (int k=0;k<numspheres;k++)
      {
        ObjectInfo hitinfo;

        hitinfo = collionCheckSphere(mirrorRay,s.spheres[k],s);
        t=hitinfo.t_value;
        if(hitinfo.hitted && hitinfo.t_value>=0 && t<tmin)
        {

            tmin = t;
            hitedMin=hitinfo;

        }
      }

      for (int k=0;k<numtris;k++)
      {
       ObjectInfo hitinfo;
       hitinfo = triangleIntersection(mirrorRay,s.triangles[k],s);
       t=hitinfo.t_value;
       if (hitinfo.hitted && hitinfo.t_value>=0 && t<tmin)
       {

           tmin = t;
           hitedMin=hitinfo;

       }
      }

      for( int ttnet = 0; ttnet< nummeshes; ttnet++)
      {
       ObjectInfo hitinfo;
       hitinfo = intersectionMesh(mirrorRay,s,s.meshes[ttnet]);
       t=hitinfo.t_value;
       if (hitinfo.hitted && hitinfo.t_value>=0 && t<tmin)
       {
           tmin = t;
           hitedMin=hitinfo;
       }
      }
      yansitma = tracer(mirrorRay, hitedMin,s, cam, (maxDepth - 1));

      pixelColor = add(pixelColor,pointWise(yansitma,s.materials[materialIndex].mirror));

  	}


  	return pixelColor;
}
