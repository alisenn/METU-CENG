#include <iostream>
#include <thread>
#include "parser.h"
#include "setAllInMain.h"
#include "tracer.h"
#include "ppm.h"

using namespace std;
using namespace parser;

Vec3f cross(const Vec3f &a, const Vec3f &b)
{
	Vec3f tmp;

	tmp.x = a.y*b.z-b.y*a.z;
	tmp.y = b.x*a.z-a.x*b.z;
	tmp.z = a.x*b.y-b.x*a.y;

	return tmp;
}

double dot(const Vec3f &a, const Vec3f &b)
{
		return a.x*b.x+a.y*b.y+a.z*b.z;
}

double length2(const Vec3f &v)
{
	return (v.x*v.x+v.y*v.y+v.z*v.z);
}

double length(const Vec3f &v)
{
	return sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
}

Vec3f normalize(const Vec3f &v)
{
	Vec3f tmp;
	double d;

	d=length(v);
	tmp.x = v.x/d;
	tmp.y = v.y/d;
	tmp.z = v.z/d;

	return tmp;
}

Vec3f add(const Vec3f &a, const Vec3f &b)
{
	Vec3f tmp;
	tmp.x = a.x+b.x;
	tmp.y = a.y+b.y;
	tmp.z = a.z+b.z;

	return tmp;
}
Vec3f subtract(const Vec3f &a, const Vec3f &b)
{
	Vec3f tmp;
	tmp.x = a.x-b.x;
	tmp.y = a.y-b.y;
	tmp.z = a.z-b.z;

	return tmp;
}
Vec3f mult(const Vec3f &a, double c)
{
	Vec3f tmp;
	tmp.x = a.x*c;
	tmp.y = a.y*c;
	tmp.z = a.z*c;

	return tmp;
}
Vec3f pointWise(const Vec3f &a, const Vec3f &b)
{
	Vec3f tmp;
	tmp.x = a.x*b.x;
	tmp.y = a.y*b.y;
	tmp.z = a.z*b.z;

	return tmp;
}
Vec3f intersectionPointFinder(const Ray &r, double t)
{
	Vec3f result;
	result.x = r.a.x + t*r.b.x;
	result.y = r.a.y + t*r.b.y;
	result.z = r.a.z + t*r.b.z;

	return result;
}
double distance(const Vec3f &a, const Vec3f &b)
{
		return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z));
}

Ray rayMaker(int i, int j, Camera cam )
{
	Ray result;
	double l,r,b,t,su_value,sv_value;
	Vec3f tmp1,tmp2,tmp3,tmp4,tmp5;
	double imageWidth,imageHeight;

	Vec3f camPos=cam.position;
	Vec3f normalGaze = normalize(cam.gaze);

	result.a=camPos;

	imageWidth=cam.image_width;
	imageHeight=cam.image_height;

	l = cam.near_plane.x;
	r = cam.near_plane.y;
	b = cam.near_plane.z;
	t = cam.near_plane.w;

	tmp1=add(camPos,mult(normalGaze,cam.near_distance));
	tmp2 = normalize(cross(normalGaze, cam.up));
	tmp3 = cross(tmp2, normalGaze);
	tmp4 = add(add(tmp1,mult(tmp2,l)),mult(tmp3,t));

	su_value = (r - l)/imageWidth*(j + 0.5);
	sv_value = (t - b)/imageHeight*(i + 0.5);

	tmp5 = add(tmp4,subtract(mult(tmp2,su_value),mult(tmp3,sv_value)));

	result.b = normalize(subtract(tmp5, camPos));
	return result;
}

ObjectInfo collionCheckSphere(const Ray &r, const Sphere &s, const Scene &scene)
{
	double A,B,C;

	double delta;
	ObjectInfo hitinfo;
	Vec3f scenter;
  double sradius;

  Vec3f p;

	double t,t1,t2;
  int i;

  scenter = scene.vertex_data[s.center_vertex_id-1];
  sradius = s.radius;


	C = (r.a.x-scenter.x)*(r.a.x-scenter.x)+(r.a.y-scenter.y)*(r.a.y-scenter.y)+(r.a.z-scenter.z)*(r.a.z-scenter.z)-sradius*sradius;

	B = 2*r.b.x*(r.a.x-scenter.x)+2*r.b.y*(r.a.y-scenter.y)+2*r.b.z*(r.a.z-scenter.z);

	A = r.b.x*r.b.x+r.b.y*r.b.y+r.b.z*r.b.z;

	delta = B*B-4*A*C;

	if (delta<0)
	{
		hitinfo.hitted = false;

		return hitinfo;
	}
	else if (delta==0)
	{
		t = -B / (2*A);
	}
	else
	{
		double tmp;
		delta = sqrt(delta);
		A = 2*A;
		t1 = (-B + delta) / A;
		t2 = (-B - delta) / A;

		if (t2<t1){
			tmp = t2;
			t2 = t1;
			t1 = tmp;
		}
		t=t1;
	}
	hitinfo.intersection = intersectionPointFinder(r, t);
	hitinfo.normal = subtract(hitinfo.intersection, scenter);
	hitinfo.normal = normalize(hitinfo.normal);
	hitinfo.material_id = s.material_id;
	hitinfo.hitted = true;
	hitinfo.t_value = t;

	return hitinfo;
}

ObjectInfo triangleIntersection(const Ray &r,const Triangle &triangle, const Scene &scene)
{
	ObjectInfo hitinfo;
	hitinfo.hitted = false;

	double  a,b,c,d,e,f,g,h,i,j,k,l;
	double beta,gamma,t;

	double eimhf,gfmdi,dhmeg,akmjb,jcmal,blmkc;

	double M;

	double dd;
	Vec3f ma,mb,mc;
	ma=scene.vertex_data[triangle.indices.v0_id-1];
	mb=scene.vertex_data[triangle.indices.v1_id-1];
	mc=scene.vertex_data[triangle.indices.v2_id-1];

	a = ma.x-mb.x;
	b = ma.y-mb.y;
	c = ma.z-mb.z;

	d = ma.x-mc.x;
	e = ma.y-mc.y;
	f = ma.z-mc.z;

	g = r.b.x;
	h = r.b.y;
	i = r.b.z;

	j = ma.x-r.a.x;
	k = ma.y-r.a.y;
	l = ma.z-r.a.z;

	eimhf = e*i-h*f;
	gfmdi = g*f-d*i;
	dhmeg = d*h-e*g;
	akmjb = a*k-j*b;
	jcmal = j*c-a*l;
	blmkc = b*l-k*c;

	M = a*eimhf+b*gfmdi+c*dhmeg;
    if (M==0) return hitinfo;

	t = -(f*akmjb+e*jcmal+d*blmkc)/M;

	gamma = (i*akmjb+h*jcmal+g*blmkc)/M;

	if (gamma<0 || gamma>1) return hitinfo;

	beta = (j*eimhf+k*gfmdi+l*dhmeg)/M;

	if (beta<0 || beta>(1-gamma)) return hitinfo;

	hitinfo.hitted = true;
	hitinfo.material_id = triangle.material_id;
	hitinfo.t_value = t;
	hitinfo.intersection = intersectionPointFinder(r, t);
	hitinfo.normal = cross(subtract(mb, ma), subtract(mc, ma));
	hitinfo.normal = normalize(hitinfo.normal);

	return hitinfo;
}

ObjectInfo intersectionMesh(const Ray &r, const Scene &s, const Mesh &m)
{
	ObjectInfo hitInfo;
  ObjectInfo hitInfoResult;
	hitInfoResult.hitted = false;
  Triangle tri;
  float min = 99999999;

	for(int i = 0; i < m.faces.size(); i++)
	{

    tri.material_id = m.material_id;
    tri.indices = m.faces[i];

		hitInfo = triangleIntersection(r, tri, s);
		if(hitInfo.hitted && hitInfo.t_value >= 0)
		{
      if(hitInfo.t_value <= min){
        min = hitInfo.t_value;
        hitInfoResult = hitInfo;
      }
		}
	}
	return hitInfoResult;
}


int main(int argc, char* argv[])
{

    Scene scene;

    scene.loadFromXml(argv[1]);
		double t;
		int numberOfThread = 16;
		int camHeight;
		int camWidth;
		int camSize=scene.cameras.size();
		for(int c=0;c<camSize;c++)
		{
			camHeight = scene.cameras[c].image_height;
			camWidth = scene.cameras[c].image_width;
			unsigned char* image = new unsigned char [camWidth * camHeight *3];
			if ( camHeight < numberOfThread) {

				setAllInMain(scene,image,0,camHeight,camWidth,c);
			}
			else
			{
				thread* threadList = new thread[numberOfThread];
				int heightinc = camHeight / numberOfThread;
				int i;
				for ( i = 0; i < numberOfThread-1; i++)
				{
					int min_height = i * heightinc;
					int max_height =(i+1)*heightinc;

					threadList[i] = thread(&setAllInMain,scene,image,min_height,max_height,camWidth,c);
				}
				threadList[i] = thread(&setAllInMain,scene,image,i * heightinc,camHeight,camWidth,c);

				for (int i = 0; i < numberOfThread; i++) threadList[i].join();
				delete[] threadList;
			}
			write_ppm(scene.cameras[c].image_name.c_str(), image, scene.cameras[c].image_width, scene.cameras[c].image_height);
			delete[] image;
		}



}
