#pragma once

namespace fst
{
    class Rotation
    {
    public:
        float angle, x, y, z;
        Rotation(float angle, float x, float y, float z);
    };
} // namespace fst
