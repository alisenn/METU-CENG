#pragma once

namespace fst
{
    class Translation
    {
    public:
        float x, y, z;
        Translation(float x, float y, float z);
    };
} // namespace fst
