#include "scaling.h"

namespace fst
{
    Scaling::Scaling(float x, float y, float z)
        : x(x)
        , y(y)
        , z(z)
    {}
}
