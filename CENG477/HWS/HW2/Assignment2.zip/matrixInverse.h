#ifndef __matrixInverse_h__
#define __matrixInverse_h__

void invert(double m[], double inv[]);

#endif //__matrixInverse_h__
