#include "translation.h"

namespace fst
{
    Translation::Translation(float x, float y, float z)
        : x(x), y(y), z(z)
    {
    }
} // namespace fst
