#pragma once


namespace fst
{
    class Scaling
    {
    public:
        float x, y, z;
        Scaling(float x, float y, float z);
    };
}
